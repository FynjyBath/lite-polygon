#!/bin/bash
# gen-input-via-stdout
