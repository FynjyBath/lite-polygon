#!/bin/bash
# gen-answer
