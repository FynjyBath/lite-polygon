@echo off
REM gen-input-via-files
