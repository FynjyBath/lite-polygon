@echo off
REM gen-input-via-file
