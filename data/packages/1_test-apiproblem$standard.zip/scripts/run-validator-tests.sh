#!/bin/bash
# run-validator-tests
