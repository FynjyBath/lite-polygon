@echo off
REM gen-input-via-stdout
