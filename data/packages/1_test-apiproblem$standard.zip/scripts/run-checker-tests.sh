#!/bin/bash
# run-checker-tests
