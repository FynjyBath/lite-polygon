#!/bin/bash
# gen-input-via-files
