#!/bin/bash
# gen-input-via-file
