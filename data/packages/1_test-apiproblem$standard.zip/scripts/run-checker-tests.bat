@echo off
REM run-checker-tests
